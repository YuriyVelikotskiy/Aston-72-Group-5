package classBuilder;

import java.time.LocalDate;

public class Author {
    private final String fullName;
    private final String country;
    private final int birthAYear;

    private Author(AuthorBuilder b) {
        this.fullName = b.fullName;
        this.country = b.country;
        this.birthAYear = b.birthAYear;
    }

    public String getFullName() { return fullName; }
    public String getCountry() { return country; }
    public int getBirthAYear() { return birthAYear; }

    @Override public String toString() {
        return "Author{fullName='" + fullName + "', country='" + country + "', birthAYear=" + birthAYear + "}";
    }

    public static class AuthorBuilder {
        private String fullName;
        private String country;
        private int birthAYear;

        public AuthorBuilder name(String fullName) { this.fullName = fullName; return this; }
        public AuthorBuilder country(String country) { this.country = country; return this; }
        public AuthorBuilder birthAYear(int year) {
            if (year > LocalDate.now().getYear() - 16) throw new IllegalArgumentException("некорректный год рождения автора");
            this.birthAYear = year; return this;
        }
        public Author build() { return new Author(this); }
    }
}
