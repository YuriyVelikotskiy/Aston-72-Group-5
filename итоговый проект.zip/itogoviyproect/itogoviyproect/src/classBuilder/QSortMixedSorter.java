package classBuilder;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.Collator;
import java.util.*;

/**
 * Стратегия сортировки смешанного списка (Author/Book/Publisher).
 * Быстрый сорт (quicksort), ключи по умолчанию:
 *  Author.fullName, Book.tile, Publisher.name
 */
public final class QSortMixedSorter {

    // ===== Strategy API =====
    public interface SortStrategy { <T> void sort(List<T> items); }

    public static final class SortContext {
        private SortStrategy strategy;
        public SortContext(SortStrategy strategy) { this.strategy = Objects.requireNonNull(strategy); }
        public void setStrategy(SortStrategy strategy) { this.strategy = Objects.requireNonNull(strategy); }
        public <T> void sort(List<T> items) { strategy.sort(items); }
    }

    // ===== Concrete Strategy (quicksort) =====
    public static final class QSortFieldStrategy implements SortStrategy {
        private final Map<Class<?>, String> propertyByClass = new HashMap<>();
        private final Map<Class<?>, Integer> typeOrder = new HashMap<>();
        private boolean ascending = true;
        private final Collator collator = Collator.getInstance(Locale.forLanguageTag("ru-RU"));

        // дефолтные свойства для известных типов (без switch/pattern)
        private static final Map<Class<?>, String> DEFAULT_PROP = Map.of(
                Author.class, "fullName",
                Book.class, "tile",          // в Book поле/геттер называется tile/getTile
                Publisher.class, "name"
        );

        /** Порядок групп (типов) в итоговой сортировке. */
        public QSortFieldStrategy setTypeOrder(Class<?>... order) {
            typeOrder.clear();
            int i = 0;
            for (Class<?> c : order) typeOrder.put(c, i++);
            return this;
        }

        /** Имя свойства/поля для класса (без get/is). */
        public QSortFieldStrategy setField(Class<?> cls, String property) {
            propertyByClass.put(Objects.requireNonNull(cls), Objects.requireNonNull(property));
            return this;
        }

        /** Направление сортировки: true — ASC (по умолчанию), false — DESC. */
        public QSortFieldStrategy setAscending(boolean asc) {
            this.ascending = asc;
            return this;
        }

        @Override
        @SuppressWarnings("unchecked") // приводим List<T> к List<Object> для in-place сортировки
        public <T> void sort(List<T> raw) {
            List<Object> list = (List<Object>) raw;
            if (list.size() <= 1) return;

            Comparator<Object> cmp = this::compareObjects;
            if (!ascending) cmp = cmp.reversed();

            quickSort(list, cmp);
        }

        // Компаратор без thenComparing — пошаговая логика сравнения
        private int compareObjects(Object o1, Object o2) {
            // 1) порядок типов
            int r1 = typeOrder.getOrDefault(o1.getClass(), Integer.MAX_VALUE);
            int r2 = typeOrder.getOrDefault(o2.getClass(), Integer.MAX_VALUE);
            int c = Integer.compare(r1, r2);
            if (c != 0) return c;

            // 2) ключевое значение
            c = compareValues(keyOf(o1), keyOf(o2));
            if (c != 0) return c;

            // 3) имя класса — для стабильности
            c = o1.getClass().getName().compareTo(o2.getClass().getName());
            if (c != 0) return c;

            // 4) строковое представление — финальный тай-брейк
            return Objects.toString(o1).compareTo(Objects.toString(o2));
        }

        private Comparable<?> keyOf(Object obj) {
            if (obj == null) return null;

            // приоритет — явно заданное свойство
            String prop = propertyByClass.get(obj.getClass());
            // иначе дефолт по карте
            if (prop == null) prop = DEFAULT_PROP.get(obj.getClass());

            Object v = (prop == null) ? null : Property.read(obj, prop);
            if (v == null) return null;
            return (v instanceof Comparable<?>) ? (Comparable<?>) v : String.valueOf(v);
        }

        private int compareValues(Comparable<?> a, Comparable<?> b) {
            if (a == b) return 0;
            if (a == null) return 1;  // nulls last
            if (b == null) return -1;
            if (a instanceof String || b instanceof String)
                return collator.compare(String.valueOf(a), String.valueOf(b));
            @SuppressWarnings("unchecked")
            Comparable<Object> aa = (Comparable<Object>) a;
            return aa.compareTo(b);
        }

        // ===== Итеративный quicksort (median-of-three) =====
        private void quickSort(List<Object> a, Comparator<Object> cmp) {
            int lo = 0, hi = a.size() - 1;
            Deque<int[]> st = new ArrayDeque<>();
            st.push(new int[]{lo, hi});
            while (!st.isEmpty()) {
                int[] rr = st.pop();
                int l = rr[0], r = rr[1];
                if (l >= r) continue;

                int p = partition(a, l, r, cmp);

                int left = p - 1 - l, right = r - (p + 1);
                if (left < right) {
                    if (l < p - 1) st.push(new int[]{l, p - 1});
                    if (p + 1 < r) st.push(new int[]{p + 1, r});
                } else {
                    if (p + 1 < r) st.push(new int[]{p + 1, r});
                    if (l < p - 1) st.push(new int[]{l, p - 1});
                }
            }
        }

        private int partition(List<Object> a, int lo, int hi, Comparator<Object> cmp) {
            int mid = lo + ((hi - lo) >>> 1);
            int m = medianIndex(a, lo, mid, hi, cmp);
            swap(a, m, hi); // pivot в конец

            Object pivot = a.get(hi);
            int i = lo - 1;
            for (int j = lo; j < hi; j++) {
                if (cmp.compare(a.get(j), pivot) <= 0) { i++; swap(a, i, j); }
            }
            swap(a, i + 1, hi);
            return i + 1;
        }

        private int medianIndex(List<Object> a, int i, int j, int k, Comparator<Object> cmp) {
            Object x=a.get(i), y=a.get(j), z=a.get(k);
            int ij=cmp.compare(x,y), jk=cmp.compare(y,z), ik=cmp.compare(x,z);
            if ((ij<=0 && jk<=0)||(ij>=0 && jk>=0)) return j;
            if ((ij<=0 && ik>=0)||(ij>=0 && ik<=0)) return i;
            return k;
        }

        private void swap(List<Object> a, int i, int j) {
            if (i==j) return;
            Object t=a.get(i); a.set(i,a.get(j)); a.set(j,t);
        }
    }

    // ===== Ридер свойств: getXxx/isXxx → поле =====
    static final class Property {
        static Object read(Object obj, String name) {
            if (obj == null || name == null || name.isEmpty()) return null;
            Class<?> cls = obj.getClass();
            String cap = Character.toUpperCase(name.charAt(0)) + name.substring(1);

            try { Method m = cls.getMethod("get" + cap); m.setAccessible(true); return m.invoke(obj); }
            catch (NoSuchMethodException ignored) {}
            catch (ReflectiveOperationException e) { throw new RuntimeException(e); }

            try { Method m = cls.getMethod("is" + cap); m.setAccessible(true); return m.invoke(obj); }
            catch (NoSuchMethodException ignored) {}
            catch (ReflectiveOperationException e) { throw new RuntimeException(e); }

            try { Field f = cls.getDeclaredField(name); f.setAccessible(true); return f.get(obj); }
            catch (NoSuchFieldException e) { return null; }
            catch (ReflectiveOperationException e) { throw new RuntimeException(e); }
        }
    }

    // ===== Мини-демо: можно запускать прямо из IDE =====
    public static void main(String[] args) {
        List<Object> list = new ArrayList<>();
        list.add(new Author.AuthorBuilder().name("А. С. Пушкин").country("Россия").birthAYear(1799).build());
        list.add(new Book.BookBuilder().tile("Евгений Онегин").yearPublished(1833).genre("Роман").build());
        list.add(new Publisher.PublisherBuilder().name("АСТ").city("Москва").foundingYear(1990).build());
        list.add(new Author.AuthorBuilder().name("Ф. М. Достоевский").country("Россия").birthAYear(1821).build());

        // ASC
        SortContext ctx = new SortContext(
                new QSortFieldStrategy()
                        .setTypeOrder(Author.class, Book.class, Publisher.class)
                        .setField(Author.class, "fullName")
                        .setField(Book.class, "tile")
                        .setField(Publisher.class, "name")
                        .setAscending(true)
        );

        System.out.println("До: " + list);
        ctx.sort(list);
        System.out.println("После (ASC): " + list);

        // DESC
        QSortFieldStrategy desc = new QSortFieldStrategy()
                .setTypeOrder(Author.class, Book.class, Publisher.class)
                .setField(Author.class, "fullName")
                .setField(Book.class, "tile")
                .setField(Publisher.class, "name")
                .setAscending(false);

        ctx.setStrategy(desc);
        ctx.sort(list);
        System.out.println("После (DESC): " + list);
    }
}
