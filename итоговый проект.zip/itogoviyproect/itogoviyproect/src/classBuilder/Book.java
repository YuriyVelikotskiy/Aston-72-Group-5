package classBuilder;

import java.time.LocalDate;

public class Book {
    private final String tile;       // именно tile
    private final int yearPublished;
    private final String genre;

    private Book(BookBuilder b) {
        this.tile = b.tile;
        this.yearPublished = b.yearPublished;
        this.genre = b.genre;
    }

    public String getTile() { return tile; }
    public int getYearPublished() { return yearPublished; }
    public String getGenre() { return genre; }

    @Override public String toString() {
        return "Book{tile='" + tile + "', yearPublished=" + yearPublished + ", genre='" + genre + "'}";
    }

    public static class BookBuilder {
        private String tile;
        private int yearPublished = LocalDate.now().getYear();
        private String genre;

        public BookBuilder tile(String tile) { this.tile = tile; return this; }
        public BookBuilder yearPublished(int year) {
            if (year > LocalDate.now().getYear()) throw new IllegalArgumentException("некорректная дата выхода книги");
            this.yearPublished = year; return this;
        }
        public BookBuilder genre(String genre) {
            if (genre != null && genre.length() > 30) throw new IllegalArgumentException("некорректный жанр книги");
            this.genre = genre; return this;
        }
        public Book build() { return new Book(this); }
    }
}
