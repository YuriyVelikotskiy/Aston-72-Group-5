package classBuilder;

import java.time.LocalDate;

public class Publisher {
    private final String name;
    private final String city;
    private final int foundingYear;

    private Publisher(PublisherBuilder b) {
        this.name = b.name; this.city = b.city; this.foundingYear = b.foundingYear;
    }

    public String getName() { return name; }
    public String getCity() { return city; }
    public int getFoundingYear() { return foundingYear; }

    @Override public String toString() {
        return "Publisher{name='" + name + "', city='" + city + "', foundingYear=" + foundingYear + "}";
    }

    public static class PublisherBuilder {
        private String name;
        private String city;
        private int foundingYear;

        public PublisherBuilder name(String name) { this.name = name; return this; }
        public PublisherBuilder city(String city) { this.city = city; return this; }
        public PublisherBuilder foundingYear(int year) {
            if (year > LocalDate.now().getYear()) throw new IllegalArgumentException("некорректная основания издательства");
            this.foundingYear = year; return this;
        }
        public Publisher build() { return new Publisher(this); }
    }
}
